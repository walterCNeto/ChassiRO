# Parecer de Controles Internos — Banco Modelo S.A.
## Ciclo 2026.Q1

Data: 4 de maio de 2026

---

## 1. Sumário executivo

Foram analisados **39 grandes temas de risco** (R0) presentes no Chassi de
Controles Internos, com base em (1) **fontes internas** — apontamentos de
auditoria, indicadores de risco (KRIs), autoavaliação das áreas, plano anual
de auditoria, BIA de continuidade, monitoramento de 2ª linha — e (2) **fontes
externas públicas** — procedentes BACEN, processos sancionadores CVM SAS,
sanções ANBIMA, Procon, mídia adversa e Reclame Aqui — e (3) **calibração
interna** — materialidade aprovada pela casa para cada risco.

A classificação combinada (impacto inerente × ambiente de controles) revela:

- **9 risco(s) em quadrante crítico** (alto impacto + controles vermelhos)
- **3 risco(s) em zona de atenção** (alto impacto + amarelo, ou médio + vermelho)
- **22 risco(s) em zona confortável** (impacto não-alto + controles verdes)

A análise da **cobertura** (% de riscos declarados nos processos do banco que
receberam algum sinal — apontamento, KRI, autoavaliação, monitoramento de 2ª
linha, auditoria, BACEN procedente, mídia adversa — nos últimos 12 meses)
evidencia:

- **19 risco(s) com cobertura alta** (≥70%) — ambiente validado
- **1 risco(s) com cobertura média** (40-70%) — monitorado parcialmente
- **0 risco(s) com cobertura baixa** (<40%) — ambiente sub-monitorado
- **19 risco(s) sem declarações** — núcleo não opera no banco ou ainda não mapeado
- **1 risco(s) declarado(s) em processos** sem nenhum sinal nos últimos 12 meses — necessitam priorização no plano de avaliação

## 2. Riscos em quadrante crítico

Requer ação imediata e visibilidade no comitê de risco:

### R0.MC.1 — Risco de adequacao (suitability)

- **Áreas envolvidas**: Asset Management | Distribuição
- **Apontamentos**: 1 aberto(s) de 1 totais
- **KRIs**: 0 vermelho(s), 0 amarelo(s) de 2 totais
- **Sinais externos**: 3 procedente(s) BACEN, 2 processo(s) CVM julgado(s), ANBIMA: 1 carta(s) + 1 termo(s)
- **Score de controles**: 6.5/10 (vermelho)
- **Score de impacto**: 4.0/5 (alto) — materialidade interna
- **Cobertura**: alta (100%) — 3/3 riscos declarados em 1 processo(s) com sinal
- **Justificativa controles**: 1 apontamento(s) aberto(s) — peso 0.5 ; Eficácia autoavaliada média 4.8/5 (ajuste -1.8) ; BACEN: 3 procedente(s) — peso 1.5 ; CVM SAS: 2 julgado(s) + 0 em curso — peso 4.0 ; ANBIMA: 1 carta(s) + 1 termo(s) — peso 0.8 ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 4/5 — Distribuicao a varejo qualificado. API mensal. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; Impacto autoavaliado máximo: 4/5

### R0.U.1 — Risco de Credito

- **Áreas envolvidas**: Crédito PF | Crédito PJ
- **Apontamentos**: 8 aberto(s) de 8 totais
- **KRIs**: 0 vermelho(s), 3 amarelo(s) de 4 totais
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.7/5 (alto) — materialidade interna
- **Cobertura**: alta (88%) — 7/8 riscos declarados em 1 processo(s) com sinal
- **Justificativa controles**: 8 apontamento(s) aberto(s) — peso 8.0 ; KRIs: 0 vermelho(s), 3 amarelo(s), 3 em piora 6m ; Eficácia autoavaliada média 2.8/5 (ajuste +0.2) ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 5/5 — Carteira de credito = 38% PR. Maior exposicao da casa. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; Impacto autoavaliado máximo: 4/5

### R0.U.13 — Risco de Privacidade (LGPD)

- **Áreas envolvidas**: Privacidade e Dados
- **Apontamentos**: 1 aberto(s) de 1 totais, **1 de regulador (BCB/CVM)**
- **KRIs**: 0 vermelho(s), 1 amarelo(s) de 2 totais
- **Sinais externos**: 17 procedente(s) BACEN, 3 mídia(s) alta severidade
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.0/5 (alto) — materialidade interna
- **Cobertura**: alta (92%) — 8/9 riscos declarados em 2 processo(s) com sinal
- **Justificativa controles**: 1 apontamento(s) aberto(s) — 1 de regulador — peso 4.0 ; KRIs: 0 vermelho(s), 1 amarelo(s) ; Eficácia autoavaliada média 3.5/5 (ajuste -0.5) ; BACEN: 17 procedente(s) — peso 6.0 ; Mídia adversa: 3 severidade alta + 0 média — peso 3.0 ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 4/5 — Base de 1.2M titulares. ANPD ativa. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; BIA: 7 processos críticos no banco (sinal indireto) ; Impacto autoavaliado máximo: 4/5

### R0.U.3 — Risco de Liquidez

- **Áreas envolvidas**: Tesouraria
- **Apontamentos**: 1 aberto(s) de 1 totais, **1 de regulador (BCB/CVM)**, **1 de severidade crítica**
- **KRIs**: 0 vermelho(s), 0 amarelo(s) de 1 totais
- **Score de controles**: 7.4/10 (vermelho)
- **Score de impacto**: 4.7/5 (alto) — materialidade interna
- **Cobertura**: alta (75%) — 6/8 riscos declarados em 1 processo(s) com sinal
- **Justificativa controles**: 1 apontamento(s) aberto(s) — 1 de regulador — peso 8.0 ; Eficácia autoavaliada média 5.0/5 (ajuste -2.0) ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 5/5 — LCR e NSFR sao restricao binding. Funding wholesale relevante. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; Impacto autoavaliado máximo: 4/5

### R0.U.4 — Risco Operacional

- **Áreas envolvidas**: Auditoria Interna | BackOffice Custódia | Compliance | Mesa de Cambio | PIX e Pagamentos | Recursos Humanos | TI Corporativo
- **Apontamentos**: 8 aberto(s) de 12 totais, **4 de regulador (BCB/CVM)**, **1 de severidade crítica**
- **KRIs**: 2 vermelho(s), 0 amarelo(s) de 4 totais
- **Sinais externos**: 38 procedente(s) BACEN
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.5/5 (alto) — materialidade interna
- **Cobertura**: alta (84%) — 40/47 riscos declarados em 13 processo(s) com sinal
- **Justificativa controles**: 8 apontamento(s) aberto(s) — 1 de regulador — peso 11.5 ; KRIs: 2 vermelho(s), 0 amarelo(s), 2 em piora 6m ; Eficácia autoavaliada média 3.9/5 (ajuste -0.9) ; BACEN: 38 procedente(s) — peso 6.0 (24 nos últimos 90d vs. 8 no período anterior — TENDÊNCIA EM ALTA +1.5) ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 5/5 — 9 nucleos de processo. Ampla exposicao operacional. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; BIA: 7 processos críticos no banco (sinal indireto) ; Impacto autoavaliado máximo: 4/5

### R0.U.5 — Risco Cibernetico

- **Áreas envolvidas**: Cibersegurança | Continuidade | PIX e Pagamentos | Privacidade e Dados | TI Corporativo | Tesouraria
- **Apontamentos**: 9 aberto(s) de 16 totais, **5 de regulador (BCB/CVM)**, **2 de severidade crítica**
- **KRIs**: 2 vermelho(s), 5 amarelo(s) de 7 totais
- **Sinais externos**: 1 mídia(s) alta severidade
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.8/5 (alto) — materialidade interna
- **Cobertura**: alta (90%) — 15/17 riscos declarados em 4 processo(s) com sinal
- **Justificativa controles**: 9 apontamento(s) aberto(s) — 2 de regulador — peso 22.5 ; KRIs: 2 vermelho(s), 5 amarelo(s), 6 em piora 6m ; Eficácia autoavaliada média 3.8/5 (ajuste -0.8) ; Mídia adversa: 1 severidade alta + 1 média — peso 1.4 ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 5/5 — Banco digital com PIX 24x7. Vetor critico em 2025/26. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; BIA: 7 processos críticos no banco (sinal indireto) ; Impacto autoavaliado máximo: 5/5

### R0.U.6 — Risco de Conformidade

- **Áreas envolvidas**: Auditoria Interna | Compliance | Jurídico | PLD
- **Apontamentos**: 2 aberto(s) de 4 totais, **1 de regulador (BCB/CVM)**
- **KRIs**: 0 vermelho(s), 1 amarelo(s) de 1 totais
- **Sinais externos**: 5 procedente(s) BACEN, 1 processo(s) CVM em curso, 1 mídia(s) alta severidade
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.2/5 (alto) — materialidade interna
- **Cobertura**: alta (99%) — 35/36 riscos declarados em 10 processo(s) com sinal
- **Justificativa controles**: 2 apontamento(s) aberto(s) — 1 de regulador — peso 5.0 ; KRIs: 0 vermelho(s), 1 amarelo(s), 1 em piora 6m ; Eficácia autoavaliada média 3.6/5 (ajuste -0.6) ; BACEN: 5 procedente(s) — peso 2.5 ; Mídia adversa: 1 severidade alta + 0 média — peso 1.0 ; CVM SAS: 0 julgado(s) + 1 em curso — peso 1.0 ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 4/5 — Regulacao densa: BCB, CVM, ANBIMA, LGPD. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; BIA: 7 processos críticos no banco (sinal indireto) ; Impacto autoavaliado máximo: 5/5

### R0.U.7 — Risco de Conduta

- **Áreas envolvidas**: Auditoria Interna | Compliance | Crédito PF | Jurídico | Ouvidoria | Recursos Humanos
- **Apontamentos**: 7 aberto(s) de 10 totais, **1 de regulador (BCB/CVM)**
- **KRIs**: 0 vermelho(s), 4 amarelo(s) de 5 totais
- **Sinais externos**: 16 procedente(s) BACEN, 1 processo(s) CVM em curso, 19 procedente(s) Procon, ANBIMA: 2 carta(s) + 1 julgamento(s)
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.0/5 (alto) — materialidade interna
- **Cobertura**: alta (100%) — 16/16 riscos declarados em 5 processo(s) com sinal
- **Justificativa controles**: 7 apontamento(s) aberto(s) — 1 de regulador — peso 9.5 ; KRIs: 0 vermelho(s), 4 amarelo(s), 2 em piora 6m ; Eficácia autoavaliada média 3.5/5 (ajuste -0.5) ; BACEN: 16 procedente(s) — peso 6.0 ; Procon: 19 procedente(s) — peso 3.0 ; CVM SAS: 0 julgado(s) + 1 em curso — peso 1.0 ; ANBIMA: 2 carta(s) + 1 julgamento(s) — peso 2.1 ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 4/5 — Distribuicao a varejo + distribuicao a investidor qualificado. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; Impacto autoavaliado máximo: 4/5

### R0.U.8 — Risco de PLD-FT

- **Áreas envolvidas**: PLD
- **Apontamentos**: 2 aberto(s) de 2 totais, **1 de severidade crítica**
- **KRIs**: 0 vermelho(s), 3 amarelo(s) de 3 totais
- **Score de controles**: 10.0/10 (vermelho)
- **Score de impacto**: 4.8/5 (alto) — materialidade interna
- **Cobertura**: alta (100%) — 8/8 riscos declarados em 2 processo(s) com sinal
- **Justificativa controles**: 2 apontamento(s) aberto(s) — peso 5.0 ; KRIs: 0 vermelho(s), 3 amarelo(s), 2 em piora 6m ; Eficácia autoavaliada média 4.0/5 (ajuste -1.0) ; Reclame Aqui: nota caiu de 7.2 para 6.5 (-0.7) — peso 1.4
- **Justificativa impacto**: Materialidade interna: 5/5 — Volume relevante de cambio + clientes high-risk. (aprovada por Carlos Mendes (CRO) em 15/01/2026) ; BIA: 7 processos críticos no banco (sinal indireto) ; Impacto autoavaliado máximo: 5/5

## 3. Riscos em zona de atenção

Monitoramento próximo e plano de ação no horizonte de 90-180 dias:

| Risco | Áreas | Apont. | KRIs V/A | Externos | C / I |
|-------|-------|--------|----------|----------|-------|
| **R0.MC.3** Risco de marcacao a mercado | Asset Management · Tesouraria | 1/1 | 0/0 | CVM 1, ANBIMA 1 | 5.9 / 4.0 |
| **R0.U.10** Risco Reputacional |  | 0/0 | 0/0 | Mídia 3 | 5.2 / 4.0 |
| **R0.U.12** Risco de Modelo | Crédito PF · Crédito PJ | 3/3 | 0/0 | — | 5.6 / 4.0 |

## 4. Riscos em zona confortável

Ambiente adequado, manter monitoramento padrão:

- **R0.B.2** Risco de pre-pagamento e recompra (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.B.4** Risco de imagem em corrida bancaria (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.CG.1** Risco de contagio intragrupo (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.CG.2** Risco de concentracao consolidada (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.CG.3** Risco de conflito estrutural (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.CG.6** Risco reputacional cruzado (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.MC.2** Risco de execucao (best execution) (Asset Management · Distribuição)
- **R0.MC.5** Risco de liquidacao (settlement) (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.MC.6** Risco de chinese wall (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.MC.7** Risco de conflito (gestor x distribuidor) (Distribuição)
- **R0.U.9** Risco Estrategico (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.CG.4** Risco de arbitragem regulatoria interna (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.CG.5** Risco de modelo agregado (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.1** Risco de subscricao (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.2** Risco de provisionamento (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.3** Risco de sinistralidade (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.4** Risco de catastrofe (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.5** Risco de longevidade (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.6** Risco de mortalidade (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.7** Risco de invalidez/morbidade (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.8** Risco de contraparte de resseguro (_sem ocorrências internas — apenas materialidade atribuída_)
- **R0.S.9** Risco de cancelamento (lapse) (_sem ocorrências internas — apenas materialidade atribuída_)

## 6. Recomendações

1. Para os riscos em quadrante crítico: alocar tratamento imediato com responsável
   nomeado pelo CRO, status reportado semanalmente até remediação.
2. Para os riscos em zona de atenção: incluir em pauta do próximo comitê
   de risco operacional e definir cronograma de remediação até final de Q2/2026.
3. Para os riscos em zona confortável: manter cobertura nos ciclos regulares de
   autoavaliação e auditoria.
4. Para os riscos sub-monitorados (cobertura baixa): priorizar inclusão no plano
   anual de auditoria, em monitoramento contínuo de 2ª linha, ou na próxima rodada
   de autoavaliação.

## 7. Metodologia

**Score de controles** (eixo X do nine-box) combina:
- **Apontamentos internos** abertos, com peso por severidade (Crítico 4, Alto 2, Médio 1, Baixo 0.5). Apontamentos de **regulador** (BCB/CVM) têm peso dobrado.
- **KRIs**: Vermelho 3, Amarelo 1. Penalidade adicional de 1 ponto por KRI com tendência de piora nos últimos 6 meses.
- **Eficácia autoavaliada** das áreas (escala 1-5). Eficácia 5 reduz score, eficácia 1 aumenta.
- **Procedentes BACEN** (peso 0.5 cada, cap 6). Penalidade adicional de 1.5 quando há tendência de piora vs. trimestre anterior.
- **CVM SAS** (regulador estatal — peso alto): processo julgado com penalidade contribui 2.0 cada; em curso 1.0 cada. Cap 6.0.
- **ANBIMA** (autorregulador — peso médio): Carta de Recomendação 0.3 cada, Termo de Compromisso 0.5 cada, Julgamento 1.5 cada. Cap 3.0.
- **Procon procedente** (peso 0.3 cada, cap 3).
- **Mídia adversa**: severidade ≥4 contribui 1.0 cada; severidade 3 contribui 0.4. Cap 4.
- **Reclame Aqui**: queda de 0.5+ na nota geral nos últimos 3 meses penaliza até 2 pontos. Nota absoluta <6.5 penaliza 1.

Escala 0-10. Verde <3, amarelo 3-6, vermelho ≥6.

**Score de impacto** (eixo Y do nine-box):
- **Materialidade interna** atribuída pela casa (CRO, Comitê de Risco) tem **peso dobrado** e prevalece.
- **Materialidade default do chassi** entra como fallback documentado quando a casa ainda não atribuiu materialidade interna.
- **Criticidade BIA** (sinal indireto para riscos universais).
- **Impacto autoavaliado** pelas áreas.

Escala 1-5. Baixo <2.5, médio 2.5-4, alto ≥4.

**Cobertura** (3ª dimensão do modelo):
- A cobertura mede **% de riscos declarados nos processos do banco que receberam algum sinal** nos últimos 12 meses.
- O denominador vem da planilha `riscos_declarados.csv`: declaração interna do banco, "no processo P, identificamos os riscos R₁, R₂, ..." (cada área dona declara). Áreas que não operam um núcleo (ex: seguros) não declaram nada para esses processos.
- O numerador vem do conjunto de TODAS as fontes: apontamentos, KRIs, autoavaliações, monitoramento de 2ª linha, plano de auditoria, BACEN procedente, Procon, mídia adversa. Se um risco declarado aparece em qualquer uma delas, conta como "avaliado".
- Cobertura por R0 = média ponderada das coberturas dos processos onde o R0 (ou seus filhos R1) foram declarados.
- A cobertura modula o score de controles: cobertura baixa + zero sinais = "ambiente desconhecido" (score sobe +2), em vez de assumir "ambiente bom".
- O nine-box reflete a cobertura no **tamanho da bolha**: bolhas pequenas = alta cobertura validada; bolhas grandes = baixa cobertura (riscos declarados sem nenhuma análise).

**Tradução de taxonomia** interna para IDs canônicos via `mapa_taxonomia.csv`.

---

*Parecer gerado automaticamente pelo pipeline ChassiRO em 04/05/2026 16:23.*
*Catálogo regulatório: github.com/walterCNeto/ChassiRO · API: chassiro-api.fly.dev*
